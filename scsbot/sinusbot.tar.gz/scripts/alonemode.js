registerPlugin({
    name: 'Oto Durdur (Önerilir)',
    version: '2.0',
    description: 'Bu Eklenti Siz Odanızda Yok Ken Müziği Durdurur. Bu Sayede Ram Ve Cpu Kullanımını Azaltmış Olursunuz.',
    author: 'Shot Script <info@Shotscript.xyz>',
    vars: [{
        name: 'mode',
        title: 'Mode',
        type: 'select',
        options: [
            'Sesi Kapat',
            'Müziği Durdur <--- Önerlien Ayar'
        ]
    }]
}, function (sinusbot, config) {
    var engine = require('engine'),
        backend = require('backend'),
        event = require('event'),
        audio = require('audio'),
        media = require('media');

    var isMuted = false,
        LastPosition = 0,
        LastTitle;

    audio.setMute(false);
    event.on('clientMove', function (ev) {
        if (backend.getCurrentChannel().getClientCount() > 1 && isMuted) {
            isMuted = false;
            engine.log('Oto Durdur Kapatılıyor');
            if (config.mode == 0) {
                audio.setMute(false);
            } else {
                LastTitle.play();
                audio.seek(LastPosition);
                engine.log('Seeking to ' + LastPosition);
            }
            return;
        }
        if (backend.getCurrentChannel().getClientCount() <= 1 && audio.isPlaying()) {
            isMuted = true;
            engine.log('Oto Durdur Başlatılıyor.');
            if (config.mode == 0) {
                audio.setMute(true);
            } else {
                LastPosition = getPos();
                engine.log('Pos is ' + LastPosition);
                LastTitle = media.getCurrentTrack();
                media.stop();
            }
        }
    });
});