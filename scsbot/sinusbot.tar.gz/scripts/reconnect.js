registerPlugin({
    name: 'Tekrar Bağlan (Önerilir)',
    version: '2.3',
    description: 'Sinusbot Herhangi Bi Şekilde Sunucudan Atılır Veya Düşerse Oto Bağlanmasını Sağlar.',
    author: 'Shotscript.xyz <info@Shotscript.xyz>',
    backends: ['ts3', 'discord'],
    vars: [
        {
            name: 'autorestart',
            title: 'Süre Sınırı Ekle',
            type: 'checkbox'
        },
        {
            name: 'restarttime',
            indent: 2,
            title: 'Saniye Cinsinden:',
            type: 'number',
            placeholder: '1440',
            conditions: [
                { field: 'autorestart', value: true }
            ]
        }
    ]
}, function(sinusbot, config) {
    var engine = require('engine');
    var backend = require('backend');
    var event = require('event');
    
    if (!config || typeof config.autorestart == 'undefined') {
        config.autorestart = false;
        engine.saveConfig(config);
    }
    if (typeof config.restarttime == 'undefined' || !config.restarttime || !parseInt(config.restarttime) || config.restarttime < 10) {
        config.restarttime = 1440;
        engine.saveConfig(config);
    }
    
    var checkConnection = function() {
        if (!backend.isConnected()) {
            backend.disconnect();
            setTimeout(function(){ backend.connect(); }, 3500);
        }
    }

    event.on('disconnect', function() {
        checkConnection();
    });
    
    event.on('clientKicked', function(moveInfo) {
        if (moveInfo.client.isSelf()) setTimeout(function(){ checkConnection(); }, 1000);
    });
    
    if (config.autorestart) {
        setInterval(function(){
            engine.log('Auto-Restart...');
            backend.disconnect();
            setTimeout(function(){ backend.connect(); }, 3500);
        }, config.restarttime * 1000 * 60);
    }
    setInterval(function(){ checkConnection(); }, 60000);
});
