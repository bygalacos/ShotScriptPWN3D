JTS3ServerMod
Author: Stefan Martens

E-Mail:
info@stefan1200.de

Homepage:
http://www.stefan1200.de


-= Inhaltsverzeichnis =-
Copyright
Informationen
Systemanforderungen
Wie kann ein flood ban auf dem TS3 Server verhindert werden
Allgemeine Informationen zur Installation und Benutzung
Bot einrichten (alle Betriebssysteme)
Bot unter Linux starten
Bot unter Windows starten
Wie finde ich die Channel ID / Eindeutige Client ID / Client Datenbank ID / Server Gruppen ID / Channel Gruppen ID
Welche Query Login Zugangsdaten verwende ich f�r den Bot
Ben�tigte Rechte f�r den Bot
Sichtbarkeit vom Bot im Teamspeak
Verschiedene Mitteilungsarten
Globale Variablen f�r Texte
Benutzung auf dem Teamspeak Server / Chat Befehle
Log Datei
Wird Hilfe ben�tigt?
Danke


-= Copyright =-
Dieses Programm darf kostenlos verwendet werden, aber bitte informiere mich, wenn ein Fehler gefunden worden ist.
Der Autor von diesem Programm ist nicht verantwortlich f�r jede Art von Sch�den oder Datenverlust!
Es ist nicht erlaubt dieses Programm zu verkaufen, es muss frei erh�ltlich sein!
Die Ver�nderung der Dateiinhalte aller Dateien, die dem JTS3ServerMod beiliegen, einschlie�lich dieser Anleitung, ist nicht gestattet!
Decompilieren ist verboten! Ebenfalls verboten ist es Teile vom Quellcode in anderen Programmen weiter zu verwenden!
Die kommerzielle Nutzung, das hei�t es wird Geld f�r den Teamspeak 3 Server oder einen Bot vom JTS3ServerMod verlangt,
ist nur nach schriftlicher Genehmigung von dem oben genannten Autor des JTS3ServerMod gestattet!

Teamspeak 3 wird entwickelt von TeamSpeak Systems GmbH, Verkauf und Lizensierungen durch Triton CI & Associates, Inc.
Weitere Informationen zu Teamspeak 3: http://www.teamspeak.com


-= Informationen =-
Dieses Programm erweitert den Teamspeak 3 Server um einige weitere Funktionen. Hier die Liste:
- Automatisches Verschieben von Mitgliedern gew�hlter Server Gruppen in bestimmte Channels, wenn kein eigener Standard Channel gesetzt ist.
- Channel Notify, sendet eine Nachricht wenn ein Client einen bestimmten Channel betritt.
- Server Group Notify, sendet eine Nachricht wenn Mitglieder gew�hlter Server Gruppen den Server betreten.
- Server Gruppen k�nnen vor unerlaubten Clients besch�tzt werden.
- Client Namen k�nnen nach unerlaubten W�rtern oder Zeichen untersucht und ggf. gekickt werden.
- Channel Namen k�nnen nach unerlaubten W�rtern oder Zeichen untersucht und ggf. gel�scht werden.
- Unt�tige (Idle) Clients in einen bestimmten Raum bewegen oder vom Server werfen. In beiden F�llen bekommt dieser eine Nachricht.
- Verschickt eine Warnnachricht an unt�tige (Idle) Clients.
- Aufnehmende Clients in einen Raum bewegen oder vom Server werfen. In beiden F�llen bekommt dieser eine Nachricht.
- Nach kurzer Zeit k�nnen Clients mit aktivierten Abwesendheitsstatus (Away) in einen Raum bewegt werden.
  Das zur�ck bewegen, wenn der Client nicht mehr abwesend ist, ist einschaltbar.
- Nach kurzer Zeit k�nnen Clients mit stumm geschalteten Kopfh�hrern oder Mikrofon in einen Raum bewegt werden.
  Das zur�ck bewegen, wenn der Client nicht mehr stumm geschaltet ist, ist einschaltbar.
- Kann in Intervallen eine Textnachricht an den Server oder bestimmten Raum Chat senden.
- Jeder Client der sich mit dem Server verbindet, kann eine Willkommensnachricht bekommen.
  Auch spezielle Willkommensnachrichten f�r bestimmte Server Gruppen m�glich.
- !lastseen Chat Befehl um auszugeben, wann jemand zuletzt auf dem Teamspeak Server war.
Alles kann ausf�hrlich eingestellt oder abgeschaltet werden.

Weitere Funktionen sind:
- Viele Bot Instanzen f�r verschiedene Teamspeak 3 Server in einem Bot Prozess sind nutzbar.
- Automatisches Neuverbinden wenn die Verbindung zum Teamspeak 3 Server verloren geht.
- Viele Chat Befehle erm�glichen unter anderem das Senden von Nachrichten, Client Informationen abfragen, das �ndern der Einstellungen,
  das Neuladen der Einstellungen oder um den Bot zu beenden.
- Langsamer Modus um die Nutzung des Bots (mit eingeschr�nkten Funktionen) auch ohne �nderung der query_ip_whitelist.txt zu erm�glichen.


-= Systemanforderungen =-
Dieses Programm wurde getestet unter Windows und Linux (auch ohne X Server).
Auf Mac OS X 10.4+, Solaris und FreeBSD sollte es ebenfalls laufen, dies ist allerdings ungetestet.
Wer es testen kann, m�ge mir bitte eine E-Mail zukommen lassen.
Alles was ben�tigt wird ist die Java SE Laufzeitumgebung Version 5 oder neuer.
Die neuste Version ist auf www.java.com oder http://www.oracle.com/technetwork/java/javase/downloads/index.html zu bekommen.
Anwender von Mac OS X 10.4 oder neuer haben es wom�glich bereits installiert.
FreeBSD Anwender k�nnen sich auf http://www.freebsd.org/de/java/ �ber Java auf FreeBSD informieren.
Linux Anwender sollten das Paket sun-java6-jre oder openjdk-7-jre
(auf �lteren Linux Versionen funktioniert auch sun-java5-jre) installieren.
Ein Beispiel f�r Debian oder Ubuntu Linux: apt-get install sun-java6-jre
Ein Beispiel f�r CentOS oder Fedora: yum install java-1.6.0-openjdk
Ein Beispiel f�r OpenSUSE: yast -i java-1_6_0-sun
Das Paket gcj-jre (GNU Java) wird nicht funktionieren!

Vielleicht soll der maximale Arbeitsspeicher, den der Bot benutzen soll, begrenzt werden.
Das kann auf einem virtuellen Server n�tzlich sein.
Dies kann mit einem Java Befehlszeilen Argument f�r die Java Virtuelle Maschine erledigt werden.
Wenn zum Beispiel nur 30 MB Arbeitsspeicher maximal verwendet werden soll, starte den Bot mit folgendem Argument:
java -mx30M -jar JTS3ServerMod.jar
Hinweis: Wenn ein zu niedriger Wert gew�hlt wird, l�uft der Bot nicht oder nicht stabil. Sinnvoll sind die Werte zwischen 30M und 50M.
Ich habe hierzu keine Langzeittests durchgef�hrt. Der Bot ben�tigt weniger Arbeitsspeicher,
wenn der Client Datenbank Cache deaktiviert wird und nur eine Bot Instanz verwendet wird.

Teamspeak 3 Server 1.0 oder neuer wird ben�tigt, empfohlen ist aber immer die neuste Version.
Nat�rlich wird auch eine Verbindung zum Teamspeak 3 Server ben�tigt.

Stelle sicher, dass die IP Adresse vom Bot in der query_ip_whitelist.txt Datei auf dem Teamspeak 3 server eingetragen ist.
Weitere Informationen hierzu im Abschnitt "-= Wie kann ein flood ban auf dem TS3 Server verhindert werden? =-" in dieser Readme Datei.


-= Wie kann ein flood ban auf dem TS3 Server verhindert werden =-
Wenn der Bot nach der Verbindung mit dem TS3 Server gebannt wird, pr�fe die Log Datei vom Bot.
Wenn folgende Zeile in der Log Datei vorhanden ist (die Zahl kann abweichen), dann sollte die L�sung funktionieren:
de.stefan1200.jts3serverquery.TS3ServerQueryException: ServerQuery Error 3331: flood ban

L�sung:
Die IP Adresse, von dem Rechner auf dem der Bot l�uft, sollte in die Datei query_ip_whitelist.txt des Teamspeak 3 Servers hinzugef�gt werden.
Wenn der Bot auf dem selben Rechner wie der TS3 Server l�uft, verwende 127.0.0.1 als TS3 Server Adresse in der Bot Konfiguration.
Diese ist in der Regel bereits freigeschaltet. Falls dies nicht beachtet wird, wird die Anti Spam Funktion
des Teamspeak 3 Server das Programm sehr oft f�r einige Minuten bannen.

Falls ein Bearbeiten der query_ip_whitelist.txt nicht m�glich ist,
versuche in der Bot Server Konfigurationsdatei den bot_slowmode auf 1 zu setzen.
Dies verlangsamt den Bot beim Verbinden und schaltet einige Funktionen ab.


-= Allgemeine Informationen zur Installation und Benutzung =-
Einfach diese ZIP Datei komplett entpacken, behalte die Verzeichnisse so bei, wie diese in der ZIP Datei vorgegeben sind.
Es ist nicht n�tig den Bot in das selbe Verzeichnis zu legen, wie den Teamspeak 3 Server,
der Bot ist ein eigenst�ndiges Programm, welches einfach eine Verbindung zum Teamspeak 3 Server Telnet Query Port herstellt.

Standardm��ig gibt es zwei Hauptkonfigurationsdateien, JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_server.cfg.
Die JTS3ServerMod_InstanceManager.cfg enth�lt alle Informationen �ber virtuelle Bot Instanzen die gestartet werden sollen.
In der Datei lassen sich auch mehrere virtuelle Bot Instanzen einrichten, wenn zum Beispiel mehrere TS3 Server einen Bot
erhalten sollen. Die JTS3ServerMod_server.cfg enth�lt alle Bot Einstellungen einer virtuellen Instanz.
Jede virtuelle Bot Instanz ben�tigt eine eigene Konfigurationsdatei.
Wird also ein weiterer Bot in der JTS3ServerMod_InstanceManager.cfg angelegt, so muss das server1 Verzeichnis kopiert und
in zum Beispiel server2 umbenannt werden. Dann muss in der JTS3ServerMod_InstanceManager.cfg auf den neuen Verzeichnisnamen
entsprechend beim neu angelegten Bot verwiesen werden.

Beide Konfigurationsdateien sollten nach eigenem Wunsch ge�ndert werden. Alles ist direkt in den Dateien erkl�rt.
F�r weitere Informationen zu den Konfigurationsdateien lese documents/ConfigHelp_deutsch.html!
Auf jeden Fall sollte beachtet werden das beide Dateien im ANSI Format (Kodierung ISO-8859-1) gespeichert werden.
Wichtig: Alle anderen Konfigurationsdateien (wie die advertising, record, idle und welcome Texte)
werden standardm��ig im Unicode (UTF-8 ohne BOM) Format gespeichert. Dies kann in der Hauptkonfigurationsdatei ge�ndert werden.

Hinweis: Es befindet sich eine deutsche �bersetzung der Konfigurationsdateien im "documents" Ordner.

Dies ist ein Kommandozeilen Programm, es ben�tigt also eine Shell um Informationen anzuzeigen.
Nat�rlich funktioniert es auch ohne aktives Shell Fenster, alle Informationen werden auch in die Log Datei geschrieben.

Unter Windows kann die cmd.exe oder die mitgelieferten EXE Dateien benutzt werden.
Linux Anwender k�nnen dieses Programm auch ohne X-Server verwenden, es wird keine GUI ge�ffnet.
Wird ein X-Server verwendet, sollte dieses Programm in der Terminal / Shell gestartet werden.
Mac OS X Anwender sollten ebenfalls die Terminal verwenden.

Wenn sich die JTS3ServerMod.jar und der config Ordner (welche die Datei JTS3ServerMod_InstanceManager.cfg enth�lt)
im selben Verzeichnis befinden, kann die Server Modifikation einfach durch folgende Eingabe gestartet werden:
java -jar JTS3ServerMod.jar

Auf virtuellen Servern sollte der Arbeitsspeicher Bedarf von der Java etwas eingeschr�nkt werden.
Weitere Informationen dazu im Abschnitt "-= Systemanforderungen =-", empfohlen ist folgender Wert:
java -mx30M -jar JTS3ServerMod.jar

Sollen sich die Dateien JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_InstanceManager.log an einem anderen Ort befinden
oder einen anderen Dateinamen haben, dann kann das Argument -config und -log verwendet werden, hier ein Beispiel:
java -jar JTS3ServerMod.jar -config cfg/instance.cfg -log log/instance.log

Ein anderes Argument ist -help, welches lediglich eine Liste der Kommandozeilenargumente ausgibt und sich dann beendet.


-= Bot einrichten (alle Betriebssysteme) =-
Als Erstes sollte gepr�ft werden, ob Java bereits installiert ist.
Dies kann auf der Konsole / Terminal / Eingabeaufforderung mit folgenden Befehl gemacht werden:
java -version
Daraufhin sollte eine Ausgabe der installierten Java Version erscheinen.
Ist dies nicht der Fall, so muss Java noch erst installiert werden.
Weitere Informationen hierzu gibt es in dem Bereich "Systemanforderungen" dieser Anleitung.

Als Zweites muss die ZIP Datei, in der diese Datei zu finden war, vollst�ndig entpackt werden.
Es ist nicht n�tig den Bot in das selbe Verzeichnis zu legen, wie den Teamspeak 3 Server,
der Bot ist ein eigenst�ndiges Programm, welches einfach eine Verbindung zum Teamspeak 3 Server Telnet Query Port herstellt.
In dem Ordner config befinden sich alle Konfigdateien, welche nach den eigenen W�nschen angepasst werden m�ssen.

Hinweis: Es befindet sich eine deutsche �bersetzung der Konfigurationsdateien im "documents" Ordner.

Wichtige Einstellungen in der Konfigdatei JTS3ServerMod_server.cfg,
diese m�ssen korrekt angegeben werden, um die Funktion vom Bot zu gew�hrleisten:
ts3_server_address
ts3_server_query_port
ts3_server_query_login
ts3_server_query_password
ts3_virtualserver_id / ts3_virtualserver_port
bot_slowmode

Standardm��ig sind alle Funktionen in der Konfigdatei abgeschaltet.
Diese m�ssen dann nach eigenen W�nschen in der bot_functions Zeile aktiviert werden.
F�r weitere Informationen zu den Funktionen lese documents/ConfigHelp_deutsch.html!
Aber geht mit folgenden Funktionen vorsichtig um, denn bei falschen Einstellungen k�nnen diese gro�e Probleme bereiten:
BadNicknameCheck
BadChannelNameCheck
InactiveChannelCheck
ServerGroupProtection

Damit der Bot eine oder mehrere Personen als Admin erkennt, eines der beiden Einstellungen setzen:
Bot Full Admin (alle Admin Befehle, nur Personen denen man vertraut!): JTS3ServerMod_InstanceManager.cfg -> bot_fulladmin_list
Bot Admin (nur die Admin Befehle der virtuellen Bot Instanz): JTS3ServerMod_server.cfg -> bot_admin_list

Damit sind die Grundeinstellungen gemacht. Alle Dateien speichern, dabei sollte beachtet werden
das die Dateien JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_server.cfg im ANSI Format (Kodierung ISO-8859-1)
gespeichert werden m�ssen. Alle anderen Konfigurationsdateien (wie die advertising, record, idle und welcome Texte)
werden standardm��ig im Unicode (UTF-8 ohne BOM) Format gespeichert.
Dies kann jedoch in der Datei JTS3ServerMod_server.cfg -> bot_messages_encoding ge�ndert werden.

Zum Starten des Bots das entsprechende folgende Kapitel lesen:
Bot unter Linux starten
Bot unter Windows starten


-= Bot unter Linux starten =-
Das erste Mal sollte der Bot so gestartet werden, wie im Abschnitt
"-= Allgemeine Informationen zur Installation und Benutzung =-" angegeben.
Sobald dann alles wie gew�nscht l�uft, bitte den Bot beenden (z.B. mit Strg + C) und wie hier beschrieben, weiter verfahren.

Eine L�sung ist die Verwendung von screen. Das Installieren von screen ist einfach (wenn nicht bereits vorhanden):
Auf Debian oder Ubuntu:
apt-get install screen
Auf CentOS oder Fedora:
yum install screen
Auf OpenSUSE:
yast -i screen

Nach dem man das gemacht hat, mit cd in den JTS3ServerMod Ordner wechseln und starte folgenden Befehl:
screen -d -m -S ts3bot java -jar JTS3ServerMod.jar
Nun wird der Bot in einem speziellen Shell Screen mit dem Namen ts3bot ausgef�hrt.

Um den Shell Screen mit dem Namen ts3bot zu �ffnen, um vielleicht die Ausgabe vom Bot zu lesen,
einfach folgenden Befehl ausf�hren:
screen -r ts3bot

Um einen ge�ffneten Shell Screen zu schliessen ohne den Bot zu beenden, einfach folgende Tastenkombination dr�cken:
STRG + A + D

Falls es hierbei zu Problemen kommt, in dieser Anleitung unter dem Punkt "Systemanforderungen"
ist beschrieben, wie man den ben�tigten Arbeitsspeicher einschr�nken kann.
Dies ist besonders auf Linux VServern interessant.
Das dort beschriebene Beispiel f�r den Start des Bots mit dem screen Befehl geht dann so:
screen -d -m -S ts3bot java -mx30M -jar JTS3ServerMod.jar

Stelle ebenfalls sicher, dass das System nicht in das Open Files Limit l�uft, wenn viele Bots gleichzeitig laufen.
Kontrolliere das Open Files Limit mit folgendem Befehl: ulimit -a
Es werden ungef�hr zwei Dateien pro virtueller Bot Instanz ben�tigt.
Beispiel: 200 Bots ben�tigen mindestens ein Open File Limit von 400.
Mit folgendem Befehl kann das Limit ge�ndert werden: ulimit -n <neues Limit>
Das �ndern von diesem Wert hat Auswirkungen auf alle Prozesse auf dem System!
Manchmal wird dieser Wert wieder auf den Standard Wert zur�ck gesetzt.
Bitte pr�fe selbst wie der neue Wert dauerhaft gesetzt werden kann.


-= Bot unter Windows starten =-
Zum Einen kann der Bot unter Windows nat�rlich als normales Programm gestartet werden.
Dazu einfach die JTS3ServerMod-Windows_NoWindow.exe mit einem Doppelklick starten.
Alle Ausgaben sind dann in der Log Datei, welche vom Bot erstellt wird, nachzulesen.
Nat�rlich kann auf eine Verkn�pfung von der JTS3ServerMod-Windows_NoWindow.exe in das
Windows Autostart Verzeichnis kopiert werden, damit der Bot bei der Anmeldung gestartet wird.
Aber stelle sicher das bei der Verkn�pfung als "Ausf�hren in" Verzeichnis das JTS3ServerMod Verzeichnis gesetzt ist.
Um das Windows Autostart Verzeichnis zu �ffnen, dr�cke die beiden Tasten Windows + R und gebe ein: shell:startup

Wenn gew�nscht, kann man den Bot auch als Windows Dienst einrichten. Dies ist komplizierter und
sollte nur gemacht werden, wenn der Bot laufen soll, ohne das ein Benutzer an Windows angemeldet ist.
Dazu, wenn noch nicht vorhanden, die Windows Server 2003 Resource Kit Tools herunterladen:
http://www.microsoft.com/downloads/en/details.aspx?FamilyID=9d467a69-57ff-4ae7-96ee-b18c4790cffd&displaylang=en
Auf neueren Windows Versionen wird eventuell eine Warnung eingeblendet,
aber auf meinem Windows 7 System funktionierte es dennoch einwandfrei.
Die Windows Server 2003 Resource Kit Tools installieren.

F�r den folgenden Vorgang habe ich bereits ein Skript vorbereitet, was alles weitere erledigt.
Im Unterordner tools befindet sich das Skript InstallWindowsService.cmd, dieses Skript
muss allerdings noch angepasst werden. Dazu muss das Skript mit einem Texteditor ge�ffnet werden.
Die Pfade bei ResourceKitPath und JTS3ServerModPath m�ssen angepasst werden um mit der eigenen Installation �bereinzustimmen.
Nach dem Speichern dieser �nderungen kann das Skript mit Administrator Rechten gestartet werden.

Der letzte Schritt ist das Starten des Dienstes, wie vom Skript am Ende beschrieben.

Wichtig:
Der Dienst kann zwar den Bot starten, allerdings nicht wieder beenden.
Dies kann dann entweder per Chat Befehl an den Bot erfolgen, oder mit dem Task Manager.


-= Wie finde ich die Channel ID / Eindeutige Client ID / Client Datenbank ID / Server Gruppen ID / Channel Gruppen ID =-
Der einfachste Weg an die Channel ID, Eindeutige Client ID und der Client Datenbank ID zu kommen,
ist die Installation von dem sehr sch�nen erweiterten Info Template von dante696:
http://addons.teamspeak.com/directory/addon/stylesheets/Extended-Client-Info.html

Wenn man es nicht installieren m�chte, l�sst sich auch mithilfe des Bots eine Channel ID herausfinden.
Dazu den Bot starten und den Chat Befehl !getchannelid <teil des Channel Namens> verwenden, um die Channel ID zu erhalten.
Als Beispiel: !getchannelid away
Wenn der Standard Wert -1 bei bot_channel_id nicht ge�ndert wird, muss man beim ersten Bot Start keine Channel ID wissen!
Bitte sicherstellen, das man sich als Bot Admin oder Full Admin eingetragen hat, sonst kann der Befehl nicht benutzt werden.

Um die Eindeutige Client ID von einem Client zu kopieren, �ffne einfach das Rechte Fenster im TS3 Client und
suche nach dem ben�tigten Client innerhalb der Servergruppen. Anschlie�end klicke mit der rechte Maustaste auf den Namen und
w�hle den Kontextmen�eintrag Eindeutige ID in die Zwischenablage kopieren. Nun kann es woanders wieder eingef�gt werden.
Auf kleineren TS3 Servern kann auch der Men�punkt Rechte -> Alle Clients anzeigen benutzt werden,
auch hier kann dies mit der rechte Maustaste kopiert werden.
Aber bei mehr als 100 Clients auf dem TS3 Server nicht wirklich sinnvoll.

Die Server Gruppen ID und Channel Gruppen ID wird im Rechte Fenster angezeigt,
nachdem man im TS3 Client auf den folgenden Men�punkt klickt:
Rechte -> Server Gruppen
Rechte -> Channel Gruppen
Direkt neben dem Gruppennamen wird die ID der Gruppe angezeigt. Nat�rlich muss man dabei mit dem Server verbunden sein.

Ein kleines Problem ist die Client Datenbank ID, weil von TS System fast alle M�glichkeiten entfernt worden sind,
sich diese ID im TS3 Client anzeigen zu lassen. Derzeit ist der einzige Weg die Verwendung von dem erweiterten Info Template.
Aber seit dem JTS3ServerMod 5.3 kann auch die Eindeutige Client ID f�r die Chat Befehle verwendet werden.
Der Bot erkennt automatisch, wenn eine Eindeutige Client ID verwendet worden ist und
fragt die Client Datenbank ID vom TS3 Server ab.


-= Welche Query Login Zugangsdaten verwende ich f�r den Bot =-
Wenn der TS3 Server selbst betrieben wird, ist der einfachste Weg die serveradmin Logindaten vom TS3 Server zu verwenden.
Dies hat bereits nahezu alle ben�tigten Rechte und man hat au�erdem auch kein Problem mit der Identit�t vom Bot.

Wenn der TS3 Server nicht selbst betrieben wird oder man nicht das serveradmin Konto verwenden m�chte,
kann auch ein neues Query Konto mit dem TS3 Client erstellt werden,
daf�r wird nur das folgende Recht ben�tigt: b_client_create_modify_serverquery_login
Aber zuerst sollte eine neue TS3 Identit�t f�r den Bot erstellt werden. Wenn man das nicht macht,
verwendet der Bot die eigene TS3 Identit�t, was alle TS3 Clients verwirrt.

Um eine neue Identit�t zu erstellen, klicke auf Einstellungen -> Identit�ten -> Hinzuf�gen
Gebe einen Namen f�r die Identit�t ein, irgendwas wie TS3 Bot oder JTS3ServerMod.
Kopiere die Eindeutige ID und schlie�e das Fenster. Nun stelle eine Verbindung mit dem TS3 Server mit
der neuen Identit�t her. Wenn die Identit�t Auswahl nicht sichtbar ist, klicke im Verbinden Fenster auf Mehr.
Nachdem dies gemacht wurde, gehe wieder als Server Admin auf den TS3 Server, wenn nicht bereits geschehen,
und �ffne das Rechte -> Server Gruppen Fenster. W�hle die Server Gruppe, die vom Bot verwendet werden soll,
zum Beispiel die Server Admin Gruppe, und f�ge die neue Identit�t zu dieser Gruppe hinzu,
indem auf Hinzuf�gen geklickt wird und die Eindeutige ID rein kopiert wird. Es sollte sichergestellt werden,
das diese Server Gruppe alle ben�tigten Rechte hat, siehe dazu den Punkt "Ben�tigte Rechte f�r den Bot"
in dieser Readme Datei. Jetzt wieder mit der neuen Identit�t verbinden, wenn nicht mehr verbunden.
Falls man mehrmals mit dem TS3 Server verbunden ist, bitte sicherstellen,
das jetzt der richtige Reiter mit der neuen Identit�t aktiv ist!
Anschlie�end im TS3 Client auf Extras -> ServerQuery Login klicken und einen Loginnamen eingeben,
den man gerne haben m�chte. Schreibe sowohl den gew�hlten Loginnamen,
als auch das vom TS3 Client vergebene Passwort auf. Dies kann jetzt f�r den Bot verwendet werden.
Au�erdem sollte diese neue Identit�t nicht mehr mit dem normalen TS3 Client verwendet werden.
Behalte aber die Identit�t gespeichert, da dar�ber das Query Login Passwort ge�ndert werden kann,
falls dies irgendwann mal notwendig ist.


-= Ben�tigte Rechte f�r den Bot =-
Stelle sicher das der Bot �ber folgende Rechte verf�gt (in Klammern steht immer, wof�r das Recht ben�tigt wird):
b_channel_delete_flag_force (Ung�ltige Channelnamen �berpr�fung)
b_channel_delete_permanent (Ung�ltige Channelnamen �berpr�fung)
b_channel_delete_semi_permanent (Ung�ltige Channelnamen �berpr�fung)
b_channel_delete_temporary (Ung�ltige Channelnamen �berpr�fung)
b_channel_join_ignore_password (Erlaube das betreten aller Channel)
b_channel_join_permanent (Erlaube das betreten aller Channel)
b_channel_join_semi_permanent (Erlaube das betreten aller Channel)
b_channel_join_temporary (Erlaube das betreten aller Channel)
b_channel_modify_name (Ung�ltige Channelnamen �berpr�fung)
b_client_channel_textmessage_send (Werbenachrichten)
b_client_ignore_sticky (Falls mit Sticky Gruppen gearbeitet wird)
b_client_info_view (Willkommensnachricht)
b_client_remoteaddress_view (F�r die Anzeige der IP Adresse)
b_client_server_textmessage_send (Werbenachrichten)
b_group_is_permanent (Der Bot bleibt Mitglied dieser Gruppe nach dem Neuverbinden)
b_serverinstance_permission_list (Anzeige der fehlenden Rechte Namen in der Log, je nach Query Account)
b_virtualserver_channel_list (Immer ben�tigt)
b_virtualserver_channelgroup_client_list (Chat Befehl !removechannelgroups)
b_virtualserver_client_dblist (Client Datenbank Cache)
b_virtualserver_client_list (Immer ben�tigt)
b_virtualserver_info_view (Immer ben�tigt)
b_virtualserver_notify_register (Immer ben�tigt)
b_virtualserver_notify_unregister (Immer ben�tigt)
b_virtualserver_select (Zum Verbinden, je nach Logindaten)
b_virtualserver_servergroup_list (Immer ben�tigt)
i_channel_join_power (Erlaube das betreten aller Channel)
i_channel_modify_power (Ung�ltige Channelnamen �berpr�fung)
i_client_complain_power (Mehrere Funktionen, wenn der "Beschwerdeeintrag" aktiviert wurde)
i_client_kick_from_channel_power (Ung�ltige Channelnamen �berpr�fung)
i_client_kick_from_server_power (Mehrere Funktionen)
i_client_move_power (Mehrere Funktionen)
i_client_permission_modify_power (Server Gruppen Schutz)
i_client_poke_power (Mehrere Funktionen wenn "poke" als Benachrichtigungstyp verwendet wird)
i_client_private_textmessage_power (Immer ben�tigt)
i_group_member_add_power (Server Gruppen Schutz)
i_group_member_remove_power (Server Gruppen Schutz)

Die "Guest Server Query" Gruppe ben�tigt au�erdem:
b_serverinstance_permission_list (Anzeige der fehlenden Rechte Namen in der Log, je nach Query Account)
b_serverquery_login (Zum Verbinden)
b_virtualserver_select (Zum Verbinden, je nach Logindaten)


-= Sichtbarkeit vom Bot im Teamspeak =-
Im Normalfall ist der Bot unsichtbar auf dem Teamspeak 3 Server, weil es nur ein Telnet Client und
kein echter Teamspeak 3 Client ist. Mit den Standard Rechten ist es einfach den Bot f�r
Teamspeak 3 Server Administratoren sichtbar zu machen.
Dazu �ffne einfach im Teamspeak 3 Client die Favoriten -> Favoriten verwalten -> w�hle den entsprechenden Server aus
und klicke, falls nicht bereits geschehen, auf Mehr. Hier aktiviere die Einstellung "ServerQuery Clients anzeigen".
Nun sollte der Bot im Teamspeak 3 Client sichtbar sein. Falls nicht, pr�fe die Rechte,
wie im n�chsten Absatz beschrieben.

Wenn es auch anderen Server Gruppen erlaubt sein soll den Bot zu sehen, f�ge einfach das Recht
i_client_serverquery_view_power zu dieser Gruppe hinzu.
Verwende einen h�heren Wert als die i_client_needed_serverquery_view_power vom Bot.
Jeder Client muss nat�rlich ebenfalls die Einstellung in den Teamspeak 3 Client Einstellungen t�tigen.


-= Verschiedene Mitteilungsarten =-
Es k�nnen verschiedene Mitteilungsarten f�r die meisten Funktionen beim Bot ausgew�hlt werden,
pr�fe daf�r die Standard JTS3ServerMod_server.cfg Datei.
Derzeit sind die Werte chat und poke g�ltig, bei einigen Funktionen ebenfalls none um die Mitteilung zu deaktivieren.
Basierend auf den Teamspeak 3 Server gibt es maximal L�ngen f�r diese Mitteilungen,
es k�nnen lediglich 100 Zeichen f�r poke Mitteilungen verwendet werden,
einschlie�lich Leerzeichen und BBCode. Chat Mitteilungen haben ein viel h�heres Limit von 1023 Zeichen,
ebenfalls einschlie�lich Leerzeichen und BBCode. Diese Grenzen sollten unbedingt beachtet werden,
ansonsten kann der Bot keine Mitteilungen verschicken und man wird eine Fehlermeldung in der Logdatei vom Bot vorfinden.

Wenn eine Nachricht als Kickgrund verschickt wird, so darf der Kickgrund nicht mehr als 80 Zeichen beinhalten.


-= Globale Variablen f�r Texte =-
Wenn dies in der Bot Konfiguration aktiviert ist, k�nnen folgende globale Variablen f�r alle Texte verwendet werden:
%SERVER_NAME% - Server Name
%SERVER_PLATFORM% - Server Betriebssystem (Windows, Linux, ...)
%SERVER_VERSION% - Server Version
%SERVER_CREATED_DATE% - Server Erstellungsdatum
%SERVER_UPTIME% - Server Uptime in Tagen, Stunden, ...
%SERVER_UPTIME_DATE% - Server Uptime als Datum
%SERVER_UPLOAD_QUOTA% - Server Upload Quota
%SERVER_DOWNLOAD_QUOTA% - Server Download Quota
%SERVER_MONTH_BYTES_UPLOADED% - Menge hochgeladender Daten im aktuellen Monat (Dateitransfer und Avatar)
%SERVER_MONTH_BYTES_DOWNLOADED% - Menge heruntergeladender Daten im aktuellen Monat (Dateitransfer und Avatar)
%SERVER_TOTAL_BYTES_UPLOADED% - Menge hochgeladender Daten insgesamt (Dateitransfer und Avatar)
%SERVER_TOTAL_BYTES_DOWNLOADED% - Menge heruntergeladender Daten insgesamt (Dateitransfer und Avatar)
%SERVER_MAX_CLIENTS% - Maximale Clients (Slots)
%SERVER_RESERVED_SLOTS% - Reservierte Slots
%SERVER_CHANNEL_COUNT% - Aktuelle Channel Anzahl
%SERVER_CLIENT_COUNT% - Aktuelle Client Anzahl
%SERVER_CLIENT_DB_COUNT% - Vollst�ndige Client Anzahl in der TS3 Datenbank
%SERVER_CLIENT_CONNECTIONS_COUNT% - Server Client Verbindungen Anzahl
Die meisten Server Informationen werden nicht sofort aktualisiert, dies geschieht alle 60 Sekunden.
Wenn diese Variablen nicht ben�tigt werden, sollten diese in der Bot Konfiguration abgeschaltet werden,
um die daf�r ben�tigte Leistung einzusparen!


-= Benutzung auf dem Teamspeak Server / Chat Befehle =-
Seit der Version 1.0 ist es m�glich einige Bot Befehle im Chat auf dem Teamspeak 3 Server zu verwenden.
Es kann der Server-, Kanal- oder Privatchat verwendet werden. Nat�rlich muss man f�r den Kanalchat im selben Kanal sein.
Es sind zu viele Befehle um diese hier alle aufzulisten. Schreibe einfach !bothelp in den Server-, Kanal- oder Privatchat.
Dies gibt eine Liste aller Befehle aus. Um zu pr�fen ob der Bot l�uft, kann auch einfach !botinfo eingegeben werden.
Um Bot Admin zu sein, muss die Einzigartige ID vom Client in der Bot Konfigurationsdatei angegeben werden.
Au�erdem befindet sich eine Liste aller Befehle in documents/ChatCommandHelp.html

Seit der Bot Version 3.1 sind zwei verschiedene Bot Admins m�glich.
Die "Full Admins" werden in der Datei JTS3ServerMod_InstanceManager.cfg eingestellt,
normale Bot Admins werden in jeder virtuellen Bot Instanz Konfigurationsdatei bei jedem Server eingestellt.
"Full Admins" k�nnen alle Bot Befehle bei jeder virtuellen Bot Instanz verwenden, nur Personen denen man vertraut hinzuf�gen!
Normale Bot Admins sind auf die eigene virtuelle Bot Instanz limitiert und k�nnen folgende Befehle gar nicht verwenden:
!exec, !execwait, !botquit, !botinstancelist, !botinstancestart, !botinstancestop


-= Log Datei =-
Dieses Programm erstellt eine Log Datei mit dem Dateinamen JTS3ServerMod_InstanceManager.log.
Die Log Datei des InstanceManager enth�lt Informationen und Fehler bez�glich des Starten und Stoppen von virtuellen Bot Instanzen.

Jede virtuelle Bot Instanz erstellt ebenfalls eine eigene Log Datei, dies kann in der JTS3ServerMod_InstanceManager.cfg
f�r jede virtuelle Bot Instanz eingestellt werden. Voreinstellung f�r die erste virtuelle Bot Instanz ist der Name JTS3ServerMod_server1.log.
Die Log Datei von der virtuellen Bot Instanz protokolliert alle Aktionen auf dem Teamspeak Server und
nat�rlich auch alle Fehler die dabei auftreten k�nnen.


-= Wird Hilfe ben�tigt? =-
Nat�rlich kann man mir eine E-Mail schreiben und das Problem so genau wie m�glich beschreiben (was passiert wann?).
Aber bitte f�ge der E-Mail die Konfig und Log Dateien vom Bot als Anhang hinzu.

Wenn mehr Informationen ben�tigt werden, wie der Bot korrekt eingerichtet werden kann, lese bitte unbedingt diese Datei vollst�ndig.
F�r weitere Informationen zu den Konfig Dateien lese bitte auch die Datei documents/ConfigHelp_deutsch.html


-= Danke =-
Ein Danke f�r das Einsenden von Fehlermeldungen und Vorschl�gen, und das Testen neuer Funktionen geht an:
- 130ng0
- ADM24
- Adam M.
- Ahmet I.
- Andr� A. / Kartoffel-Stampfer
- Atranox / End-Gaming.eu
- BEN89
- Baggavy J.
- Benjamin B.
- Benjamin L.
- BoKo / WebShell
- Bralosch
- ChoosenEye
- Chris / Orange Bots
- Christoph
- Christopher / Lenzen Networks
- Corba
- DaRkBoZ
- Daniel L.
- DarRoe
- DarkGhost
- David K.
- Denden / TSforYOU
- Dr.No
- DunklerKeks / Dark Empire Clan
- EidEchse
- FRAGGYNZ
- Fabrice
- Felix R.
- Flavio
- Flofus
- FoXFTW
- Frank B.
- Fusionpot
- GWR
- Gamle / MainGaming.dk
- Giftzwerg
- Guus W.
- Heiko
- Hermann W.
- Hinken
- HoschY1987
- Invictus International / TS Server HQ
- IronMC
- Jay / Clanwarz
- Jeremy P.
- Johannes1509
- KingHunt / Gamers Platoon
- Kirbyfan1223
- Lore
- MajorThorn
- Mariuszeq
- Marko M.
- Mateusz Z.
- Megamaluco
- Micha5
- Mikolaj
- MrChicken
- NaTesTa10
- NanooTec
- Nate4ever
- Nobody_cbm / Software Galaxy
- Pascal / Fierlord-Hosting
- Patschi
- Philip H. / squaX
- Pierre N. / Next-Host
- Prototype
- Raiden4918 / Subculture-Gaming
- Robert M.
- Robin B. / TS3-4You
- Rowtag
- Sandro M. / TS Voice
- Saucenteufel
- Sebastian S.
- SkullDrago
- Slater
- Speddyroot
- St3v3
- Stefan R.
- Surf3rDud3
- TS-Coach
- Taishou / NLFS B�ndnis
- TeaTow
- Thomas / Science System
- ThomasHH / thl-online
- TotoIsBack
- Tukaa
- WaterFlow
- Yanek
- barricas
- cigaming
- dukio
- eggster
- elpoepel
- kadama / Oxivoice
- livedisco
- mastermax
- mathewitp / Old Dragons
- mthomas
- sojakfa
- thecrew
- tigerle
- whvler
- xeomueller / xgs.in
- xoun
Liste in Alphabetischer Reihenfolge.